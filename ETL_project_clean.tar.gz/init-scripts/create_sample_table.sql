-- Создание таблицы для данных из sample.csv
CREATE TABLE IF NOT EXISTS sample_data (
    id INTEGER PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    age INTEGER NOT NULL,
    city VARCHAR(255) NOT NULL
);

-- Создание индексов для оптимизации запросов (опционально)
CREATE INDEX IF NOT EXISTS idx_sample_data_name ON sample_data(name);
CREATE INDEX IF NOT EXISTS idx_sample_data_age ON sample_data(age);
CREATE INDEX IF NOT EXISTS idx_sample_data_city ON sample_data(city);

-- Комментарии к таблице и столбцам для документирования (опционально)
COMMENT ON TABLE sample_data IS 'Данные из файла sample.csv';
COMMENT ON COLUMN sample_data.id IS 'Уникальный идентификатор записи';
COMMENT ON COLUMN sample_data.name IS 'Имя';
COMMENT ON COLUMN sample_data.age IS 'Возраст';
COMMENT ON COLUMN sample_data.city IS 'Город';
