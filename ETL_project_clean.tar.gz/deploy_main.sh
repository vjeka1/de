#!/bin/bash

echo "Запускаем все контейнеры..."
docker compose up -d

echo "Ожидание полной инициализации NiFi (80 секунд)..."
sleep 80

echo "Останавливаем NiFi для замены конфигурации..."
docker stop nifi

echo "Копируем новые файлы конфигурации..."
docker cp ./flow.json.gz nifi:/opt/nifi/nifi-current/conf/flow.json.gz
docker cp ./flow.xml.gz nifi:/opt/nifi/nifi-current/conf/flow.xml.gz

echo "Запускаем NiFi с новой конфигурацией..."
docker start nifi

echo "Настраиваем права доступа..."
docker exec -u 0 nifi chmod 644 /opt/nifi/nifi-current/conf/flow.json.gz
docker exec -u 0 nifi chmod 644 /opt/nifi/nifi-current/conf/flow.xml.gz
docker exec -u 0 nifi chown nifi:nifi /opt/nifi/nifi-current/conf/flow.json.gz
docker exec -u 0 nifi chown nifi:nifi /opt/nifi/nifi-current/conf/flow.xml.gz

echo "Готово! NiFi запущен с новой конфигурацией. Проверьте веб-интерфейс через 1-2 минуты."

